# Fact-check verification scripts

Independent BFS verification of the claims in three slide decks (checked 2026-07-21):

1. `cc3-zk-n-graph-slides-v2.pdf` — $G_3(k,n)$, consecutive 3-cycle graphs
2. `cc4-zk-n-graph-slides.pdf` — $G_4(k,n)$, consecutive 4-cycle graphs
3. `df-v2l-tree-v4d-slides.pdf` — tree token graphs $\Gamma(T,k)$

## Files

| Script | Deck | Runtime | Dependencies |
|---|---|---|---|
| `verify_g3.py` | cc3 | ~1–2 min | none |
| `verify_g4.py` | cc4 (small/medium, up to $G_4(10,20)$) | ~1–2 min | none |
| `verify_g4_large.py` | cc4 (heavy: $H_3(8,24)$, $G_4(12,25)$, full $G_4(13,27)$) | ~6–8 min | numpy |
| `verify_trees.py` | df-v2l | ~1 min | none |

Run each with `python3 <script>.py`. All are single-file and Kaggle-friendly.
`verify_g4_large.py` uses a flat `uint8` distance array of size $2^n$
(134 MB for $n=27$) with a level-synchronous NumPy BFS; 4-bit window
rotations are table lookups.

## Findings

### Deck 1 ($G_3$): one problem, on slide 18

Everything else verified: exact formula $d(A,B)=\frac{I+\Delta}{2}$,
$h=\lfloor\Delta/2\rfloor$, mismatch families and all four counting formulas
$m(n,3..6)$, both distance bounds (all-pairs), diameter
$\lceil k(n-k)/2\rceil$ with attainment, and the $G_3(3,6)$ figure claims.

**Slide 18 edge-count table**: the listed $|E|$ values count generator
applications (a multigraph convention), not edges of the simple graph
defined on slide 4 — parallel moves exist (two distinct moves send $0101$
to $0011$). Simple-graph counts: 10, 21, 54, 110, 260. Moreover the
$(3,7)$ entry (147) matches *neither* convention; the generator-application
count is 150. The derived $2|E|/|V| = 8.40$ inherits the error.
Cosmetic: title slide names the file `cc4-...-v2.tex` in the cc3 deck.

### Deck 2 ($G_4$): one problem, on slide 9

Everything else verified, including **all five distribution tables exactly**
(the 20M-vertex $G_4(13,27)$ table digit-for-digit), $|E_4|=30$, the
$k\le 4$ closed formulas, the $(110)^5$ example, diameters
$D_A = \lceil k(n-k)/3\rceil$ for $(4,10),(9,20),(12,25)$, the farthest-layer
multiset $\{0,0,0,0,1\}$, and $H_1(1,n)$, $H_1(2,n)$,
$H_2(5,n)=\binom{\lfloor n/3\rfloor}{5}$, $H_3(8,24)=1$.

**Slide 9 suffix-block family**: the claim
$a=(0,\dots,0,t,\dots,t) \Rightarrow d=\lceil pt/3\rceil,\ h_4=0$
is **false for $p=1$, $t\equiv 2 \pmod 3$**: e.g. $a=(2)$ gives $d=2$,
not 1 — contradicting the deck's own $k=1$ formula $d=q+r$. It held for
$p\ge 2$ in all tested cases. Suggested fix: require $p\ge 2$ (or exclude
$t\equiv 2$ when $p=1$).

Convention note: the small tables include $A$ in the $h_4{=}0$ count; the
$G_4(13,27)$ table excludes $A$ (counts sum to $\binom{27}{13}-1$).

### Deck 3 (trees): clean, no errors

Main theorem verified against BFS on random trees (all $k$, all pairs);
$\mathrm{diam}\,\Gamma(D_n,k)=k(n-k)-1$ and $\Gamma(P_n,k)=k(n-k)$ for
$n=4..8$; the full $E_6$ worked example including the geodesic;
$|E(\Gamma(T,k))|=|E(T)|\binom{n-2}{k-1}$; all large-number claims
including the exact 76-digit $|E(\Gamma(D_{252},126))|$; all puzzle state
counts; all three references (incl. Mathey-Prévot–Valette,
L'Enseignement Math. 69 (2023), 315–333).
