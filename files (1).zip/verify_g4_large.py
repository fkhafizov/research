"""Heavy-case verification for cc4-zk-n-graph-slides.pdf.

Verifies via full BFS:
  1. H3(8,24) = 1 = C(floor(24/3), 8)            (~735k vertices,  ~15 s)
  2. D_A(G4(12,25)) = 52 = ceil(12*13/3)         (~5.2M vertices,  ~1 min)
  3. Full h4 distribution of G4(13,27):          (~20M vertices,   ~4-5 min, needs numpy)
       h4=0: 7,568,546 (37.73%)   h4=1: 11,955,665 (59.60%)
       h4=2:   531,946 (2.65%)    h4=3:      2,142 (0.0107%)

State encoding: bit j of a uint32 = s_j. Distance table is a flat uint8 array
of size 2^n (255 = unvisited) -- 134 MB for n=27. BFS is level-synchronous
and fully vectorized with numpy; the 4-bit window rotations are table lookups.

Requires: numpy. Total runtime ~6-8 min. Kaggle-friendly.
"""

import time
from math import comb, ceil
from collections import deque

import numpy as np


ROT_L = np.array([(w >> 1) | ((w & 1) << 3) for w in range(16)], dtype=np.uint32)
ROT_R = np.array([((w << 1) & 0xF) | (w >> 3) for w in range(16)], dtype=np.uint32)


def bfs_numpy(n, k, verbose=False):
    """Level-synchronous BFS over G4(k,n) from A = 0^k 1^{n-k}.
    Returns (dist_uint8_array_of_size_2^n, A)."""
    A = ((1 << (n - k)) - 1) << k
    dist = np.full(1 << n, 255, dtype=np.uint8)
    dist[A] = 0
    frontier = np.array([A], dtype=np.uint32)
    full = np.uint32((1 << n) - 1)
    level = 0
    while frontier.size:
        outs = []
        for i in range(n - 3):
            sh = np.uint32(i)
            w = (frontier >> sh) & np.uint32(0xF)
            base = frontier & np.uint32(~(0xF << i) & 0xFFFFFFFF) & full
            outs.append(base | (ROT_L[w] << sh))
            outs.append(base | (ROT_R[w] << sh))
        cand = np.unique(np.concatenate(outs))
        cand = cand[dist[cand] == 255]
        level += 1
        dist[cand] = level
        frontier = cand
        if verbose and level % 10 == 0:
            print(f"    level {level}: frontier {cand.size}")
    return dist, A


def area_vec(v, n):
    """Vectorized I(B) for an array of states."""
    I = np.zeros(v.size, dtype=np.int64)
    zc = np.zeros(v.size, dtype=np.int64)
    for j in range(n):
        is_zero = ((v >> np.uint32(j)) & np.uint32(1)) == 0
        I[is_zero] += j - zc[is_zero]          # (j+1) - (zc+1)
        zc[is_zero] += 1
    return I


def h_distribution(n, k, verbose=False, include_A=False):
    """h4 distribution over the component of A.

    Convention note: the slide's small tables (G4(2,5)...G4(10,20)) include
    the canonical vertex A in the h4=0 count; the G4(13,27) table excludes A
    (its counts sum to C(27,13) - 1). Set include_A accordingly.
    """
    t0 = time.time()
    dist, A = bfs_numpy(n, k, verbose)
    visited = np.where(dist != 255)[0].astype(np.uint32)
    I = area_vec(visited, n)
    h = dist[visited].astype(np.int64) - (I + 2) // 3      # ceil(I/3)
    mask = np.ones(visited.size, dtype=bool) if include_A else (visited != A)
    vals, cnts = np.unique(h[mask], return_counts=True)
    return (len(visited), int(dist[visited].max()),
            dict(zip(vals.tolist(), cnts.tolist())), time.time() - t0)


if __name__ == "__main__":
    print("=== H3(8,24): expect exactly 1 vertex with h4=3 ===")
    V, DA, hs, t = h_distribution(24, 8)
    print(f"  |CA|={V} (C(24,8)={comb(24, 8)}), h-dist={hs}, "
          f"H3={hs.get(3, 0)} vs C(8,8)=1, {t:.0f}s")

    print("\n=== G4(12,25): expect D_A = 52 ===")
    V, DA, hs, t = h_distribution(25, 12)
    print(f"  |CA|={V} (C(25,12)={comb(25, 12)}), D_A={DA}, "
          f"ceil(12*13/3)={ceil(12 * 13 / 3)}, {t:.0f}s")

    print("\n=== G4(13,27): full 20M-vertex distribution table ===")
    V, DA, hs, t = h_distribution(27, 13, verbose=True)
    tot = sum(hs.values())
    print(f"  |CA|={V} (C(27,13)={comb(27, 13)}), D_A={DA}, {t:.0f}s")
    claims = {0: 7568546, 1: 11955665, 2: 531946, 3: 2142}
    for h in sorted(hs):
        print(f"    h4={h}: {hs[h]:>10}  ({100 * hs[h] / tot:.4f}%)  "
              f"slide: {claims.get(h)}  match: {hs[h] == claims.get(h)}")
