"""Verification of claims in df-v2l-tree-v4d-slides.pdf  (tree token graph deck).

Checks:
  1. Main theorem d_{Gamma(T,k)}(X,Y) = sum_e |eta_e(X) - eta_e(Y)|
     against all-pairs BFS on random trees (all k, all pairs)
  2. diam Gamma(D_n, k) = k(n-k) - 1  and  diam Gamma(P_n, k) = k(n-k)
     for n = 4..8, all k
  3. E6 worked example: eta(A)=(1,0,0,0,0), eta(B)=(2,2,2,1,0), d(A,B)=6;
     the 6-step chain is a valid geodesic; diam comparison E6/D6/P6 = 6/7/8
  4. Token-graph edge count |E| = |E(T)| * C(n-2, k-1) on small trees
  5. Big-number claims: C(100,25), 99*C(98,24), avg degree 37.5,
     C(252,126), 251*C(250,125), exact 76-digit edge count, ratios
  6. Puzzle state counts (Rubik 3x3/4x4, Megaminx, Professor's Cube)

Pure Python, no dependencies. Runs in ~1 min.
"""

import random
from itertools import combinations
from collections import deque
from math import comb


# ----------------------------------------------------------------------
# Token graph machinery
# ----------------------------------------------------------------------

def make_adj(edges, n):
    adj = {i: [] for i in range(1, n + 1)}
    for a, b in edges:
        adj[a].append(b)
        adj[b].append(a)
    return adj


def token_neighbors(X, adj):
    for u in X:
        for v in adj[u]:
            if v not in X:
                yield frozenset(X - {u} | {v})


def bfs(src, adj):
    dist = {src: 0}
    q = deque([src])
    while q:
        u = q.popleft()
        for v in token_neighbors(u, adj):
            if v not in dist:
                dist[v] = dist[u] + 1
                q.append(v)
    return dist


def heights(X, edges, n, root=1):
    """eta_e(X) for every edge, keyed by the child endpoint (the vertex
    of e farther from the root). eta_e = #tokens in the subtree below e."""
    adj = make_adj(edges, n)
    parent, order = {root: None}, [root]
    q = deque([root])
    while q:
        u = q.popleft()
        for v in adj[u]:
            if v not in parent:
                parent[v] = u
                q.append(v)
                order.append(v)
    sub = {v: (1 if v in X else 0) for v in range(1, n + 1)}
    for v in reversed(order):
        if parent[v] is not None:
            sub[parent[v]] += sub[v]
    return {v: sub[v] for v in order if parent[v] is not None}


def l1_distance(X, Y, edges, n):
    HX, HY = heights(X, edges, n), heights(Y, edges, n)
    return sum(abs(HX[v] - HY[v]) for v in HX)


def diam_token(edges, n, k):
    adj = make_adj(edges, n)
    return max(max(bfs(frozenset(c), adj).values())
               for c in combinations(range(1, n + 1), k))


# tree families -------------------------------------------------------

def path_edges(n):
    return [(i, i + 1) for i in range(1, n)]


def Dn_edges(n):
    return [(i, i + 1) for i in range(1, n - 2)] + [(n - 2, n - 1), (n - 2, n)]


def E_edges(n):
    """Trunk 1-2-...-(n-1), branch leaf n attached at vertex 3 (slide 21)."""
    return [(i, i + 1) for i in range(1, n - 1)] + [(3, n)]


def random_tree(n, seed):
    rng = random.Random(seed)
    return [(rng.randint(1, v - 1), v) for v in range(2, n + 1)]


# ----------------------------------------------------------------------
# Checks
# ----------------------------------------------------------------------

def check_main_theorem():
    print("=== main theorem: BFS distance vs L1 of height vectors ===")
    ok = True
    for seed in range(6):
        n = random.Random(seed).randint(5, 8)
        edges = random_tree(n, seed * 17 + 3)
        adj = make_adj(edges, n)
        for k in range(1, n):
            V = [frozenset(c) for c in combinations(range(1, n + 1), k)]
            for X in V:
                dX = bfs(X, adj)
                for Y in V:
                    if dX[Y] != l1_distance(X, Y, edges, n):
                        ok = False
                        print("  FAIL:", n, k, edges, X, Y)
    print(f"  verified on 6 random trees, all k, all pairs: {ok}")


def check_diameters():
    print("\n=== diam Gamma(D_n,k) = k(n-k)-1;  diam Gamma(P_n,k) = k(n-k) ===")
    ok = True
    for n in range(4, 9):
        for k in range(1, n):
            dD = diam_token(Dn_edges(n), n, k)
            dP = diam_token(path_edges(n), n, k)
            if dD != k * (n - k) - 1 or dP != k * (n - k):
                ok = False
                print(f"  MISMATCH n={n} k={k}: D={dD}, P={dP}")
    print(f"  verified for n=4..8, all k: {ok}")


def check_e6_example():
    print("\n=== E6 worked example (slides 23-25) ===")
    n, edges = 6, E_edges(6)
    adj = make_adj(edges, n)
    A, B = frozenset({1, 2}), frozenset({4, 5})
    HA, HB = heights(A, edges, n), heights(B, edges, n)
    order = [2, 3, 4, 5, 6]                       # edges e1..e4 then branch
    print(f"  eta(A) = {[HA[v] for v in order]}   (claim (1,0,0,0,0))")
    print(f"  eta(B) = {[HB[v] for v in order]}   (claim (2,2,2,1,0))")
    print(f"  d(A,B) = {bfs(A, adj)[B]}   (claim 6)")

    chain = ["110000", "101000", "100100", "100010", "010010", "001010", "000110"]
    to_set = lambda s: frozenset(i + 1 for i, c in enumerate(s) if c == "1")
    ok = all(to_set(b) in set(token_neighbors(to_set(a), adj))
             for a, b in zip(chain, chain[1:]))
    print(f"  6-step chain is a valid geodesic: {ok and to_set(chain[-1]) == B}")
    print(f"  diam: E6={diam_token(edges, 6, 2)}, D6={diam_token(Dn_edges(6), 6, 2)}, "
          f"P6={diam_token(path_edges(6), 6, 2)}   (claim 6, 7, 8)")


def check_edge_count_formula():
    print("\n=== |E(Gamma(T,k))| = |E(T)| * C(n-2, k-1) ===")
    ok = True
    for name, edges, n in [("P6", path_edges(6), 6),
                           ("D7", Dn_edges(7), 7),
                           ("E6", E_edges(6), 6)]:
        adj = make_adj(edges, n)
        for k in range(1, n):
            E = set()
            for c in combinations(range(1, n + 1), k):
                X = frozenset(c)
                for Y in token_neighbors(X, adj):
                    E.add(frozenset((X, Y)))
            if len(E) != len(edges) * comb(n - 2, k - 1):
                ok = False
                print(f"  FAIL {name} k={k}")
    print(f"  verified on P6, D7, E6 for all k: {ok}")


def check_big_numbers():
    print("\n=== big-number claims (slides 18-19, 28-32) ===")
    v, e = comb(100, 25), 99 * comb(98, 24)
    print(f"  C(100,25)   = {v:.3e}   (claim 2.43e23)")
    print(f"  99*C(98,24) = {e:.3e}   (claim 4.55e24);  2|E| = {2 * e:.3e} (claim 9.09e24)")
    print(f"  avg degree  = {2 * e / v}   (claim 37.5)")

    V, E = comb(252, 126), 251 * comb(250, 125)
    print(f"  C(252,126)    = {V:.3e}   (claim 3.63e74, {len(str(V))} digits)")
    print(f"  251*C(250,125)= {E:.4e}  (claim 2.289e76)")
    print(f"  E/V = {E / V} (claim 63);  avg degree = {2 * E / V} (claim 126)")
    slide_exact = int("22893300098974613611622017384487282592294844338217541432733"
                      "522920094075250752")
    print(f"  exact 76-digit |E| matches slide: {E == slide_exact}")

    puzzles = [("3x3x3", 43252003274489856000, "4.33e19", 20),
               ("4x4x4", 7401196841564901869874093974498574336000000000, "7.40e45", 46),
               ("Megaminx", 100669616553523347122516032313645505168688116411019768627200000000000, "1.01e68", 69),
               ("5x5x5", 282870942277741856536850800000000000000000000000000000000000000000000000000, "2.83e74", 75)]
    for name, val, claim, digits in puzzles:
        print(f"  {name:<9}: {val:.3e} (claim {claim}), digits {len(str(val))} "
              f"(claim {digits})")


if __name__ == "__main__":
    check_main_theorem()
    check_diameters()
    check_e6_example()
    check_edge_count_formula()
    check_big_numbers()
