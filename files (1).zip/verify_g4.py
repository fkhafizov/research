"""Verification of claims in cc4-zk-n-graph-slides.pdf  (G_4(k,n) deck).

Checks, via exhaustive BFS (tuple-based for small graphs, bitmask BFS for
medium graphs up to ~200k vertices):

  1.  Max increase of I(B) per move is 3
  2.  Obstruction A=00111, B=10101: I=3, d=2, h4=1; padded family d=2
  3.  Closed formulas for k=1 (d=q+r), k=2, k=3 (residues {0,1,2})
  4.  k=4: h4 in {0,1}, determined by residue word; |E4| = 30
  5.  Sharp families: a_i = 0 mod 3 => h4=0;  suffix-block family
      *** exposes the slide-9 counterexample: p=1, t = 2 (mod 3) ***
  6.  k=5, n=15, B=(110)^5: d=12, h4=2
  7.  Distribution tables G4(2,5), (4,8), (6,12), (8,16), (10,20)
  8.  D_A for (4,10)=8 and (9,20)=33; farthest layer h-values {0,0,0,0,1}
  9.  Quasi-polynomials H1(1,n), H1(2,n), H2(5,n)=C(floor(n/3),5)

For the heavy cases -- H3(8,24)=1, G4(12,25) D_A=52, and the full
G4(13,27) table -- see verify_g4_large.py.

Pure Python, no dependencies. Runs in ~1-2 min.
"""

from itertools import combinations
from collections import deque, Counter
from math import comb, ceil


# ----------------------------------------------------------------------
# Graph machinery (tuple states)
# ----------------------------------------------------------------------

def vertices(k, n):
    for zeros in combinations(range(n), k):
        s = [1] * n
        for z in zeros:
            s[z] = 0
        yield tuple(s)


def g4_neighbors(s):
    """Consecutive 4-block rotations x0x1x2x3 -> x1x2x3x0 and its inverse."""
    n = len(s)
    for i in range(n - 3):
        blk = s[i:i + 4]
        if blk == (0, 0, 0, 0) or blk == (1, 1, 1, 1):
            continue
        t = list(s); t[i:i + 4] = [s[i + 1], s[i + 2], s[i + 3], s[i]]
        yield tuple(t)
        t = list(s); t[i:i + 4] = [s[i + 3], s[i], s[i + 1], s[i + 2]]
        yield tuple(t)


def bfs(source):
    dist = {source: 0}
    q = deque([source])
    while q:
        u = q.popleft()
        for v in g4_neighbors(u):
            if v not in dist:
                dist[v] = dist[u] + 1
                q.append(v)
    return dist


# ----------------------------------------------------------------------
# Fast bitmask BFS for medium graphs (bit j of the int = s_j)
# ----------------------------------------------------------------------

def bfs_int(n, k):
    A = ((1 << (n - k)) - 1) << k          # 0^k 1^{n-k}: ones occupy high bits
    dist = {A: 0}
    q = deque([A])
    while q:
        u = q.popleft()
        du1 = dist[u] + 1
        for i in range(n - 3):
            w = (u >> i) & 0xF
            if w == 0 or w == 0xF:
                continue
            base = u & ~(0xF << i)
            for nw in ((w >> 1) | ((w & 1) << 3), ((w << 1) & 0xF) | (w >> 3)):
                v = base | (nw << i)
                if v not in dist:
                    dist[v] = du1
                    q.append(v)
    return dist, A


def area_int(u, n):
    I, idx = 0, 1
    for j in range(n):
        if not (u >> j) & 1:
            I += (j + 1) - idx
            idx += 1
    return I


# ----------------------------------------------------------------------
# Statistics
# ----------------------------------------------------------------------

def zp(s):
    return [i + 1 for i, b in enumerate(s) if b == 0]


def displ(s):
    return [z - (i + 1) for i, z in enumerate(zp(s))]


def area(s):
    return sum(displ(s))


def canonical(k, n):
    return tuple([0] * k + [1] * (n - k))


def h4(s, d):
    return d - ceil(area(s) / 3)


# ----------------------------------------------------------------------
# Checks
# ----------------------------------------------------------------------

def check_move_bound():
    print("=== max increase of I per move ===")
    mx = 0
    for k, n in [(3, 8), (4, 9), (5, 11)]:
        for B in vertices(k, n):
            I0 = area(B)
            for v in g4_neighbors(B):
                mx = max(mx, area(v) - I0)
    print(f"  max delta-I over sampled graphs: {mx}  (slide claims <= 3)")


def check_obstruction():
    print("\n=== obstruction and padding family ===")
    d = bfs(canonical(2, 5))
    B = (1, 0, 1, 0, 1)
    print(f"  G4(2,5): I(10101)={area(B)}, d={d[B]}, h4={h4(B, d[B])}  (claim: 3, 2, 1)")
    ok = True
    for m in range(3):
        for p in range(3):
            Ap = tuple([0] * (m + 2) + [1] * (p + 3))
            Bp = tuple([0] * m + [1, 0, 1, 0, 1] + [1] * p)
            if bfs(Ap)[Bp] != 2 or area(Bp) != 3:
                ok = False
    print(f"  padded family (m,p in 0..2): I=3, d=2 always: {ok}")


def check_closed_cases():
    print("\n=== closed formulas k=1,2,3 and k=4 residue control ===")
    ok = all(bfs(canonical(1, n))[B] == sum(divmod(displ(B)[0], 3))
             for n in range(4, 16) for B in bfs(canonical(1, n)))
    print(f"  k=1: d = q + r for a1 = 3q + r, n=4..15: {ok}")

    ok = okres = True
    for n in range(5, 14):
        d = bfs(canonical(2, n))
        for B, dv in d.items():
            a = displ(B)
            if dv != ceil((a[0] + a[1] + (a[0] % 3)) / 3):
                ok = False
            pred = 1 if (a[0] % 3, a[1] % 3) in {(1, 2), (2, 0), (2, 1)} else 0
            if h4(B, dv) != pred:
                okres = False
    print(f"  k=2: ceiling formula: {ok};  h4=1 residue criterion: {okres}")

    ok = True
    for n in range(7, 13):                       # requires n-k >= 4
        d = bfs(canonical(3, n))
        for B, dv in d.items():
            pred = 1 if set(x % 3 for x in displ(B)) == {0, 1, 2} else 0
            if h4(B, dv) != pred:
                ok = False
    print(f"  k=3: h4=1 iff residues = {{0,1,2}}, n=7..12: {ok}")

    words, consistent = {}, True
    for n in range(7, 13):
        d = bfs(canonical(4, n))
        for B, dv in d.items():
            r = tuple(x % 3 for x in displ(B))
            hh = h4(B, dv)
            if hh not in (0, 1):
                consistent = False
            if words.setdefault(r, hh) != hh:
                consistent = False
    E4 = sum(1 for v in words.values() if v == 1)
    print(f"  k=4: h4 in {{0,1}}, residue-word determined: {consistent}; "
          f"|E4| = {E4} (claim 30)")


def check_sharp_families():
    print("\n=== slide 9 sharp families ===")
    ok_div3, fails = True, []
    for n in range(6, 13):
        for k in range(1, min(6, n - 3) + 1):
            d = bfs(canonical(k, n))
            for B, dv in d.items():
                a = displ(B)
                if all(x % 3 == 0 for x in a) and h4(B, dv) != 0:
                    ok_div3 = False
                nz = [x for x in a if x != 0]
                if nz and len(set(nz)) == 1 and all(x == 0 for x in a[:len(a) - len(nz)]):
                    t, p = nz[0], len(nz)
                    if dv != ceil(p * t / 3):
                        fails.append((k, n, tuple(a), dv, ceil(p * t / 3)))
    print(f"  all a_i = 0 (mod 3) => h4 = 0: {ok_div3}")
    print(f"  suffix-block claim d = ceil(pt/3): {len(fails)} counterexamples")
    for k, n, a, dv, pred in fails[:4]:
        print(f"    e.g. k={k}, n={n}, a={a}: actual d={dv}, claimed {pred}"
              f"   (p=1, t = 2 mod 3)")
    if fails:
        print("  --> claim is FALSE for p=1, t = 2 (mod 3); holds for p >= 2 in "
              "all tested cases.")


def check_k5_example():
    print("\n=== k=5 h4=2 example ===")
    d = bfs(canonical(5, 15))
    B = tuple([1, 1, 0] * 5)
    print(f"  B=(110)^5: a={displ(B)}, r={[x % 3 for x in displ(B)]}, "
          f"I={area(B)}, d={d[B]}, h4={h4(B, d[B])}  (claim: I=30, d=12, h4=2)")


def check_tables():
    print("\n=== distribution tables and diameters ===")
    claims = {(2, 5):  (10, 3,  {0: 8, 1: 2}),
              (4, 8):  (70, 6,  {0: 57, 1: 13}),
              (6, 12): (924, 12, {0: 681, 1: 243}),
              (8, 16): (12870, 22, {0: 7017, 1: 5832, 2: 21}),
              (10, 20): (184756, 34, {0: 96265, 1: 86931, 2: 1560})}
    for (k, n), (cV, cDA, chs) in claims.items():
        dist, _ = bfs_int(n, k)
        DA = max(dist.values())
        hs = Counter(dv - ceil((area_int(u, n) + 0) / 3) for u, dv in dist.items())
        hs = dict(sorted(hs.items()))
        ok = len(dist) == cV and DA == cDA and hs == chs
        print(f"  G4({k},{n}): |CA|={len(dist)}, D_A={DA}, h-dist={hs}  match slide: {ok}")

    dist, _ = bfs_int(10, 4)
    DA = max(dist.values())
    far_h = sorted(dv - ceil(area_int(u, 10) / 3) for u, dv in dist.items() if dv == DA)
    print(f"  G4(4,10): D_A={DA} (claim 8 = ceil(24/3)); farthest-layer h4 = {far_h} "
          f"(claim {{0,0,0,0,1}})")
    dist, _ = bfs_int(20, 9)
    print(f"  G4(9,20): D_A={max(dist.values())} (claim 33 = ceil(99/3))")


def check_quasipolynomials():
    print("\n=== quasi-polynomial counts ===")
    ok = True
    for n in range(4, 20):
        d = bfs(canonical(1, n))
        H1 = sum(1 for B, dv in d.items() if B != canonical(1, n) and h4(B, dv) == 1)
        if H1 != n // 3:
            ok = False
    print(f"  H1(1,n) = floor(n/3), n=4..19: {ok}")
    ok = True
    for n in range(5, 16):
        d = bfs(canonical(2, n))
        H1 = sum(1 for B, dv in d.items() if B != canonical(2, n) and h4(B, dv) == 1)
        pred = n * (n - 3) // 6 if n % 3 == 0 else (n - 1) * (n - 2) // 6
        if H1 != pred:
            ok = False
    print(f"  H1(2,n) period-3 formula, n=5..15: {ok}")
    for n in range(12, 19):
        dist, _ = bfs_int(n, 5)
        H2 = sum(1 for u, dv in dist.items() if dv - ceil(area_int(u, n) / 3) == 2)
        print(f"  H2(5,{n}) = {H2}  vs C(floor(n/3),5) = {comb(n // 3, 5)}  "
              f"match: {H2 == comb(n // 3, 5)}")


if __name__ == "__main__":
    check_move_bound()
    check_obstruction()
    check_closed_cases()
    check_sharp_families()
    check_k5_example()
    check_tables()
    check_quasipolynomials()
