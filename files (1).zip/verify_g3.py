"""Verification of claims in cc3-zk-n-graph-slides-v2.pdf  (G_3(k,n) deck).

Checks, via exhaustive BFS:
  1. Exact distance formula  d(A,B) = (I(B) + Delta(B)) / 2
  2. h(B) = d - ceil(I/2) = floor(Delta/2);  mismatch <=> Delta > I mod 2
  3. No mismatches for k = 1, 2; every mismatch has h = 1 for k = 3..6
  4. Mismatch families and counting formulas m(n,3), m(n,4), m(n,5), m(n,6)
  5. Distance bounds for arbitrary pairs (all-pairs check)
  6. Diameter = ceil(k(n-k)/2), attained between 0^k 1^{n-k} and 1^{n-k} 0^k
  7. Edge counts: simple-graph vs generator-application (multigraph) convention
     -> exposes the slide-18 discrepancy, including the (3,7) row.

Pure Python, no dependencies. Runs in ~1-2 min.
"""

from itertools import combinations
from collections import deque, Counter
from math import comb, ceil


# ----------------------------------------------------------------------
# Graph machinery
# ----------------------------------------------------------------------

def vertices(k, n):
    """All binary strings (tuples) of length n with exactly k zeros."""
    for zeros in combinations(range(n), k):
        s = [1] * n
        for z in zeros:
            s[z] = 0
        yield tuple(s)


def g3_neighbors(s):
    """Consecutive 3-cycle moves: forward (a,b,c)->(c,a,b), reverse (a,b,c)->(b,c,a)."""
    n = len(s)
    for i in range(n - 2):
        a, b, c = s[i], s[i + 1], s[i + 2]
        if a == b == c:
            continue
        t = list(s); t[i], t[i + 1], t[i + 2] = c, a, b
        yield tuple(t)
        t = list(s); t[i], t[i + 1], t[i + 2] = b, c, a
        yield tuple(t)


def bfs(source):
    dist = {source: 0}
    q = deque([source])
    while q:
        u = q.popleft()
        for v in g3_neighbors(u):
            if v not in dist:
                dist[v] = dist[u] + 1
                q.append(v)
    return dist


# ----------------------------------------------------------------------
# Statistics from the slides
# ----------------------------------------------------------------------

def zero_positions(s):                       # 1-indexed
    return [i + 1 for i, b in enumerate(s) if b == 0]


def stats(s):
    """Return (I, Delta) with d_i = z_i - i, p_i = d_i mod 2,
    Delta = |sum (-1)^{i+1} p_i|."""
    zp = zero_positions(s)
    d = [z - (i + 1) for i, z in enumerate(zp)]
    I = sum(d)
    p = [x % 2 for x in d]
    Delta = abs(sum(((-1) ** i) * p[i] for i in range(len(p))))
    return I, Delta


def canonical(k, n):
    return tuple([0] * k + [1] * (n - k))


# ----------------------------------------------------------------------
# 1-3, 6: formula / h / mismatch / diameter checks
# ----------------------------------------------------------------------

def check_formula_and_diameter():
    print("=== distance formula, h-offset, mismatch structure, diameter ===")
    cases = [(k, n) for k in range(1, 7) for n in range(k + 2, k + 8) if comb(n, k) <= 4000]
    for k, n in cases:
        A = canonical(k, n)
        dist = bfs(A)
        assert len(dist) == comb(n, k), f"G3({k},{n}) not connected?"
        bad_formula = bad_h = mism = mism_bad_h = 0
        for B, dv in dist.items():
            I, Delta = stats(B)
            if (I + Delta) % 2 or dv != (I + Delta) // 2:
                bad_formula += 1
            h = dv - ceil(I / 2)
            if h != Delta // 2:
                bad_h += 1
            if h > 0:
                mism += 1
                if k <= 6 and h != 1:
                    mism_bad_h += 1
        Bfar = tuple([1] * (n - k) + [0] * k)
        DA = max(dist.values())
        ok = (bad_formula == 0 and bad_h == 0 and mism_bad_h == 0
              and DA == ceil(k * (n - k) / 2) and dist[Bfar] == DA)
        print(f"  G3({k:>2},{n:>2}): formula ok, h=floor(D/2) ok, "
              f"mismatches={mism:>4}, D_A={DA}=ceil(k(n-k)/2), all pass: {ok}")


# ----------------------------------------------------------------------
# 4: mismatch families and counting formulas
# ----------------------------------------------------------------------

def m_formula(k, n):
    f, c = n // 2, (n + 1) // 2          # even / odd positions available
    if k == 3:
        return comb(f, 3)
    if k == 4:
        return comb(f, 4) + comb(c, 4)
    if k == 5:
        return comb(f, 5) + comb(c, 5) + comb(f, 4) * c
    if k == 6:
        return comb(f, 6) + comb(c, 6) + comb(f, 5) * c + f * comb(c, 5)
    raise ValueError


def check_mismatch_counts():
    print("\n=== mismatch counting formulas m(n,k), k=3..6 ===")
    for k in (3, 4, 5, 6):
        for n in range(k + 2, k + 8):
            if comb(n, k) > 4000:
                break
            A = canonical(k, n)
            dist = bfs(A)
            cnt = 0
            fams = Counter()
            for B, dv in dist.items():
                I, _ = stats(B)
                if dv - ceil(I / 2) > 0:
                    cnt += 1
                    ne = sum(1 for z in zero_positions(B) if z % 2 == 0)
                    fams[(ne, k - ne)] += 1     # (#even zeros, #odd zeros)
            pred = m_formula(k, n)
            print(f"  k={k} n={n:>2}: BFS={cnt:>4}  formula={pred:>4}  "
                  f"match={cnt == pred}  families(E,O)={dict(fams)}")


# ----------------------------------------------------------------------
# 5: bounds for arbitrary pairs
# ----------------------------------------------------------------------

def check_bounds():
    print("\n=== bounds  ceil(L1/2) <= d(X,Y) <= sum ceil(|xi-yi|/2)  (all pairs) ===")
    for k, n in [(2, 5), (3, 6), (3, 7), (4, 8)]:
        V = list(vertices(k, n))
        ok = True
        for X in V:
            dX = bfs(X)
            zx = zero_positions(X)
            for Y in V:
                zy = zero_positions(Y)
                diffs = [abs(a - b) for a, b in zip(zx, zy)]
                lo, hi = ceil(sum(diffs) / 2), sum(ceil(d / 2) for d in diffs)
                if not lo <= dX[Y] <= hi:
                    ok = False
                    print("  BOUND FAIL:", X, Y, dX[Y], lo, hi)
        print(f"  G3({k},{n}): bounds hold for all pairs: {ok}")


# ----------------------------------------------------------------------
# 7: edge count conventions (slide 18)
# ----------------------------------------------------------------------

def check_edge_counts():
    print("\n=== slide 18 edge-count table: convention comparison ===")
    claims = {(2, 4): 12, (2, 5): 27, (3, 6): 72, (3, 7): 147, (4, 8): 360}
    print(f"  {'(k,n)':>7} {'slide':>6} {'simple':>7} {'gen-apps/2':>11}")
    for (k, n), claim in claims.items():
        simple = set()
        directed = 0
        for u in vertices(k, n):
            for i in range(n - 2):
                if not (u[i] == u[i + 1] == u[i + 2]):
                    directed += 2          # sigma+ and sigma-
            for v in g3_neighbors(u):
                simple.add(frozenset((u, v)))
        print(f"  ({k},{n})  {claim:>6} {len(simple):>7} {directed // 2:>11}"
              + ("   <-- matches neither convention" if claim not in (len(simple), directed // 2) else ""))
    print("  Note: parallel generator moves exist (e.g. two distinct moves send"
          " 0101 to 0011),\n  so the simple graph of slide 4 has fewer edges than"
          " the generator-application count.")


if __name__ == "__main__":
    check_formula_and_diameter()
    check_mismatch_counts()
    check_bounds()
    check_edge_counts()
